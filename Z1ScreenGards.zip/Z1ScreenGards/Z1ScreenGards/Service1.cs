﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;

namespace Z1ScreenGards
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Task.Factory.StartNew(getstart);
        }
        static int ival = 0;
        protected override void OnStop()
        {
            ival = 10;
        }
        private void getstart()
        {
            GDI32.Example ex = new  GDI32.Example();
            int i = 0;
            string dt = "";
            for (;;)
            {
                dt = DateTime.Now.ToString("yyyyMMddhhmmss");
                i++;
                ex.CaptureScreen("D:\\Screenshots\\" + dt + "_" + i + ".png", ImageFormat.Png);
                Thread.Sleep(1000);
                if (ival != 0)
                    break;
            }
        }
    }
    public class GDI32
    {
        [DllImport("GDI32.dll")]
        public static extern bool BitBlt(int hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, int hdcSrc, int nXSrc, int nYSrc, int dwRop);
        [DllImport("GDI32.dll")]
        public static extern int CreateCompatibleBitmap(int hdc, int nWidth, int nHeight);[DllImport("GDI32.dll")]
        public static extern int CreateCompatibleDC(int hdc);
        [DllImport("GDI32.dll")]
        public static extern bool DeleteDC(int hdc);
        [DllImport("GDI32.dll")]
        public static extern bool DeleteObject(int hObject);
        [DllImport("GDI32.dll")]
        public static extern int GetDeviceCaps(int hdc, int nIndex);
        [DllImport("GDI32.dll")]
        public static extern int SelectObject(int hdc, int hgdiobj);
        public class User32
        {
            [DllImport("User32.dll")]
            public static extern int GetDesktopWindow();
            [DllImport("User32.dll")]
            public static extern int GetWindowDC(int hWnd);
            [DllImport("User32.dll")]
            public static extern int ReleaseDC(int hWnd, int hDC);
        }
        public class Example
        {
            public void CaptureScreen(string fileName, ImageFormat imageFormat)
            {
                int hdcSrc = User32.GetWindowDC(User32.GetDesktopWindow()),
                hdcDest = GDI32.CreateCompatibleDC(hdcSrc),
                hBitmap = GDI32.CreateCompatibleBitmap(hdcSrc,
                GDI32.GetDeviceCaps(hdcSrc, 8), GDI32.GetDeviceCaps(hdcSrc, 10)); GDI32.SelectObject(hdcDest, hBitmap);
                GDI32.BitBlt(hdcDest, 0, 0, GDI32.GetDeviceCaps(hdcSrc, 8),
                GDI32.GetDeviceCaps(hdcSrc, 10), hdcSrc, 0, 0, 0x00CC0020);
                SaveImageAs(hBitmap, fileName, imageFormat);
                Cleanup(hBitmap, hdcSrc, hdcDest);
            }
            private void Cleanup(int hBitmap, int hdcSrc, int hdcDest)
            {
                User32.ReleaseDC(User32.GetDesktopWindow(), hdcSrc);
                GDI32.DeleteDC(hdcDest);
                GDI32.DeleteObject(hBitmap);
            }
            private void SaveImageAs(int hBitmap, string fileName, ImageFormat imageFormat)
            {
                Bitmap image =
                new Bitmap(Image.FromHbitmap(new IntPtr(hBitmap)),
                Image.FromHbitmap(new IntPtr(hBitmap)).Width,
                Image.FromHbitmap(new IntPtr(hBitmap)).Height);
                image.Save(fileName, imageFormat);
            }
        }
    }

}
