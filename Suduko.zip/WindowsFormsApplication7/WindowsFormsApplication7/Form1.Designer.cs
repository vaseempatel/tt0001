﻿namespace WindowsFormsApplication7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(302, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 81;
            this.button1.Text = "Check";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 21);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(47, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(65, 21);
            this.textBox2.MaxLength = 1;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(47, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "0";
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(117, 21);
            this.textBox3.MaxLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(47, 20);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "0";
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(170, 21);
            this.textBox4.MaxLength = 1;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(47, 20);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "0";
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(225, 21);
            this.textBox5.MaxLength = 1;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(47, 20);
            this.textBox5.TabIndex = 4;
            this.textBox5.Text = "0";
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(278, 21);
            this.textBox6.MaxLength = 1;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(47, 20);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "0";
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(330, 21);
            this.textBox7.MaxLength = 1;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(47, 20);
            this.textBox7.TabIndex = 6;
            this.textBox7.Text = "0";
            this.textBox7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(383, 21);
            this.textBox8.MaxLength = 1;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(47, 20);
            this.textBox8.TabIndex = 7;
            this.textBox8.Text = "0";
            this.textBox8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(438, 21);
            this.textBox9.MaxLength = 1;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(47, 20);
            this.textBox9.TabIndex = 8;
            this.textBox9.Text = "0";
            this.textBox9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(12, 47);
            this.textBox10.MaxLength = 1;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(47, 20);
            this.textBox10.TabIndex = 9;
            this.textBox10.Text = "0";
            this.textBox10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(12, 73);
            this.textBox19.MaxLength = 1;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(47, 20);
            this.textBox19.TabIndex = 18;
            this.textBox19.Text = "0";
            this.textBox19.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(65, 47);
            this.textBox11.MaxLength = 1;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(47, 20);
            this.textBox11.TabIndex = 10;
            this.textBox11.Text = "0";
            this.textBox11.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(12, 99);
            this.textBox28.MaxLength = 1;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(47, 20);
            this.textBox28.TabIndex = 27;
            this.textBox28.Text = "0";
            this.textBox28.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(12, 125);
            this.textBox37.MaxLength = 1;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(47, 20);
            this.textBox37.TabIndex = 36;
            this.textBox37.Text = "0";
            this.textBox37.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(65, 73);
            this.textBox20.MaxLength = 1;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(47, 20);
            this.textBox20.TabIndex = 19;
            this.textBox20.Text = "0";
            this.textBox20.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(12, 151);
            this.textBox46.MaxLength = 1;
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(47, 20);
            this.textBox46.TabIndex = 45;
            this.textBox46.Text = "0";
            this.textBox46.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(117, 47);
            this.textBox12.MaxLength = 1;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(47, 20);
            this.textBox12.TabIndex = 11;
            this.textBox12.Text = "0";
            this.textBox12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(12, 177);
            this.textBox55.MaxLength = 1;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(47, 20);
            this.textBox55.TabIndex = 54;
            this.textBox55.Text = "0";
            this.textBox55.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(65, 99);
            this.textBox29.MaxLength = 1;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(47, 20);
            this.textBox29.TabIndex = 28;
            this.textBox29.Text = "0";
            this.textBox29.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(12, 203);
            this.textBox64.MaxLength = 1;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(47, 20);
            this.textBox64.TabIndex = 63;
            this.textBox64.Text = "0";
            this.textBox64.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(12, 229);
            this.textBox73.MaxLength = 1;
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(47, 20);
            this.textBox73.TabIndex = 72;
            this.textBox73.Text = "0";
            this.textBox73.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(65, 125);
            this.textBox38.MaxLength = 1;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(47, 20);
            this.textBox38.TabIndex = 37;
            this.textBox38.Text = "0";
            this.textBox38.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(117, 73);
            this.textBox21.MaxLength = 1;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(47, 20);
            this.textBox21.TabIndex = 20;
            this.textBox21.Text = "0";
            this.textBox21.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(65, 151);
            this.textBox47.MaxLength = 1;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(47, 20);
            this.textBox47.TabIndex = 46;
            this.textBox47.Text = "0";
            this.textBox47.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(170, 47);
            this.textBox13.MaxLength = 1;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(47, 20);
            this.textBox13.TabIndex = 12;
            this.textBox13.Text = "0";
            this.textBox13.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(65, 177);
            this.textBox56.MaxLength = 1;
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(47, 20);
            this.textBox56.TabIndex = 55;
            this.textBox56.Text = "0";
            this.textBox56.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(117, 99);
            this.textBox30.MaxLength = 1;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(47, 20);
            this.textBox30.TabIndex = 29;
            this.textBox30.Text = "0";
            this.textBox30.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(65, 203);
            this.textBox65.MaxLength = 1;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(47, 20);
            this.textBox65.TabIndex = 64;
            this.textBox65.Text = "0";
            this.textBox65.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(65, 229);
            this.textBox74.MaxLength = 1;
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(47, 20);
            this.textBox74.TabIndex = 73;
            this.textBox74.Text = "0";
            this.textBox74.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(117, 125);
            this.textBox39.MaxLength = 1;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(47, 20);
            this.textBox39.TabIndex = 38;
            this.textBox39.Text = "0";
            this.textBox39.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(170, 73);
            this.textBox22.MaxLength = 1;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(47, 20);
            this.textBox22.TabIndex = 21;
            this.textBox22.Text = "0";
            this.textBox22.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(117, 151);
            this.textBox48.MaxLength = 1;
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(47, 20);
            this.textBox48.TabIndex = 47;
            this.textBox48.Text = "0";
            this.textBox48.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(225, 47);
            this.textBox14.MaxLength = 1;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(47, 20);
            this.textBox14.TabIndex = 13;
            this.textBox14.Text = "0";
            this.textBox14.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(117, 177);
            this.textBox57.MaxLength = 1;
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(47, 20);
            this.textBox57.TabIndex = 56;
            this.textBox57.Text = "0";
            this.textBox57.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(170, 99);
            this.textBox31.MaxLength = 1;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(47, 20);
            this.textBox31.TabIndex = 30;
            this.textBox31.Text = "0";
            this.textBox31.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(117, 203);
            this.textBox66.MaxLength = 1;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(47, 20);
            this.textBox66.TabIndex = 65;
            this.textBox66.Text = "0";
            this.textBox66.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(117, 229);
            this.textBox75.MaxLength = 1;
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(47, 20);
            this.textBox75.TabIndex = 74;
            this.textBox75.Text = "0";
            this.textBox75.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(170, 125);
            this.textBox40.MaxLength = 1;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(47, 20);
            this.textBox40.TabIndex = 39;
            this.textBox40.Text = "0";
            this.textBox40.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(222, 73);
            this.textBox23.MaxLength = 1;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(47, 20);
            this.textBox23.TabIndex = 22;
            this.textBox23.Text = "0";
            this.textBox23.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(170, 151);
            this.textBox49.MaxLength = 1;
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(47, 20);
            this.textBox49.TabIndex = 48;
            this.textBox49.Text = "0";
            this.textBox49.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(274, 47);
            this.textBox15.MaxLength = 1;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(47, 20);
            this.textBox15.TabIndex = 14;
            this.textBox15.Text = "0";
            this.textBox15.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(170, 177);
            this.textBox58.MaxLength = 1;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(47, 20);
            this.textBox58.TabIndex = 57;
            this.textBox58.Text = "0";
            this.textBox58.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(222, 99);
            this.textBox32.MaxLength = 1;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(47, 20);
            this.textBox32.TabIndex = 31;
            this.textBox32.Text = "0";
            this.textBox32.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(170, 203);
            this.textBox67.MaxLength = 1;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(47, 20);
            this.textBox67.TabIndex = 66;
            this.textBox67.Text = "0";
            this.textBox67.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(170, 229);
            this.textBox76.MaxLength = 1;
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(47, 20);
            this.textBox76.TabIndex = 75;
            this.textBox76.Text = "0";
            this.textBox76.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(222, 125);
            this.textBox41.MaxLength = 1;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(47, 20);
            this.textBox41.TabIndex = 40;
            this.textBox41.Text = "0";
            this.textBox41.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(274, 73);
            this.textBox24.MaxLength = 1;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(47, 20);
            this.textBox24.TabIndex = 23;
            this.textBox24.Text = "0";
            this.textBox24.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(222, 151);
            this.textBox50.MaxLength = 1;
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(47, 20);
            this.textBox50.TabIndex = 49;
            this.textBox50.Text = "0";
            this.textBox50.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(330, 47);
            this.textBox16.MaxLength = 1;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(47, 20);
            this.textBox16.TabIndex = 15;
            this.textBox16.Text = "0";
            this.textBox16.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(222, 177);
            this.textBox59.MaxLength = 1;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(47, 20);
            this.textBox59.TabIndex = 58;
            this.textBox59.Text = "0";
            this.textBox59.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(274, 99);
            this.textBox33.MaxLength = 1;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(47, 20);
            this.textBox33.TabIndex = 32;
            this.textBox33.Text = "0";
            this.textBox33.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(222, 203);
            this.textBox68.MaxLength = 1;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(47, 20);
            this.textBox68.TabIndex = 67;
            this.textBox68.Text = "0";
            this.textBox68.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(222, 229);
            this.textBox77.MaxLength = 1;
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(47, 20);
            this.textBox77.TabIndex = 76;
            this.textBox77.Text = "0";
            this.textBox77.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(274, 125);
            this.textBox42.MaxLength = 1;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(47, 20);
            this.textBox42.TabIndex = 41;
            this.textBox42.Text = "0";
            this.textBox42.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(330, 73);
            this.textBox25.MaxLength = 1;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(47, 20);
            this.textBox25.TabIndex = 24;
            this.textBox25.Text = "0";
            this.textBox25.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(274, 151);
            this.textBox51.MaxLength = 1;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(47, 20);
            this.textBox51.TabIndex = 50;
            this.textBox51.Text = "0";
            this.textBox51.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(383, 47);
            this.textBox17.MaxLength = 1;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(47, 20);
            this.textBox17.TabIndex = 16;
            this.textBox17.Text = "0";
            this.textBox17.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(274, 177);
            this.textBox60.MaxLength = 1;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(47, 20);
            this.textBox60.TabIndex = 59;
            this.textBox60.Text = "0";
            this.textBox60.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(330, 99);
            this.textBox34.MaxLength = 1;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(47, 20);
            this.textBox34.TabIndex = 33;
            this.textBox34.Text = "0";
            this.textBox34.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(274, 203);
            this.textBox69.MaxLength = 1;
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(47, 20);
            this.textBox69.TabIndex = 68;
            this.textBox69.Text = "0";
            this.textBox69.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(274, 229);
            this.textBox78.MaxLength = 1;
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(47, 20);
            this.textBox78.TabIndex = 77;
            this.textBox78.Text = "0";
            this.textBox78.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(438, 47);
            this.textBox18.MaxLength = 1;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(47, 20);
            this.textBox18.TabIndex = 17;
            this.textBox18.Text = "0";
            this.textBox18.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(330, 125);
            this.textBox43.MaxLength = 1;
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(47, 20);
            this.textBox43.TabIndex = 42;
            this.textBox43.Text = "0";
            this.textBox43.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(383, 73);
            this.textBox26.MaxLength = 1;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(47, 20);
            this.textBox26.TabIndex = 25;
            this.textBox26.Text = "0";
            this.textBox26.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(330, 151);
            this.textBox52.MaxLength = 1;
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(47, 20);
            this.textBox52.TabIndex = 51;
            this.textBox52.Text = "0";
            this.textBox52.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(438, 73);
            this.textBox27.MaxLength = 1;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(47, 20);
            this.textBox27.TabIndex = 26;
            this.textBox27.Text = "0";
            this.textBox27.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(330, 177);
            this.textBox61.MaxLength = 1;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(47, 20);
            this.textBox61.TabIndex = 60;
            this.textBox61.Text = "0";
            this.textBox61.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(383, 99);
            this.textBox35.MaxLength = 1;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(47, 20);
            this.textBox35.TabIndex = 34;
            this.textBox35.Text = "0";
            this.textBox35.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(330, 203);
            this.textBox70.MaxLength = 1;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(47, 20);
            this.textBox70.TabIndex = 69;
            this.textBox70.Text = "0";
            this.textBox70.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(330, 229);
            this.textBox79.MaxLength = 1;
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(47, 20);
            this.textBox79.TabIndex = 78;
            this.textBox79.Text = "0";
            this.textBox79.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(438, 99);
            this.textBox36.MaxLength = 1;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(47, 20);
            this.textBox36.TabIndex = 35;
            this.textBox36.Text = "0";
            this.textBox36.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(383, 125);
            this.textBox44.MaxLength = 1;
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(47, 20);
            this.textBox44.TabIndex = 43;
            this.textBox44.Text = "0";
            this.textBox44.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(438, 125);
            this.textBox45.MaxLength = 1;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(47, 20);
            this.textBox45.TabIndex = 44;
            this.textBox45.Text = "0";
            this.textBox45.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(383, 151);
            this.textBox53.MaxLength = 1;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(47, 20);
            this.textBox53.TabIndex = 52;
            this.textBox53.Text = "0";
            this.textBox53.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(438, 151);
            this.textBox54.MaxLength = 1;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(47, 20);
            this.textBox54.TabIndex = 53;
            this.textBox54.Text = "0";
            this.textBox54.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(383, 177);
            this.textBox62.MaxLength = 1;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(47, 20);
            this.textBox62.TabIndex = 61;
            this.textBox62.Text = "0";
            this.textBox62.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(438, 177);
            this.textBox63.MaxLength = 1;
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(47, 20);
            this.textBox63.TabIndex = 62;
            this.textBox63.Text = "0";
            this.textBox63.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(383, 203);
            this.textBox71.MaxLength = 1;
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(47, 20);
            this.textBox71.TabIndex = 70;
            this.textBox71.Text = "0";
            this.textBox71.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(383, 229);
            this.textBox80.MaxLength = 1;
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(47, 20);
            this.textBox80.TabIndex = 79;
            this.textBox80.Text = "0";
            this.textBox80.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(438, 203);
            this.textBox72.MaxLength = 1;
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(47, 20);
            this.textBox72.TabIndex = 71;
            this.textBox72.Text = "0";
            this.textBox72.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(438, 229);
            this.textBox81.MaxLength = 1;
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(47, 20);
            this.textBox81.TabIndex = 80;
            this.textBox81.Text = "0";
            this.textBox81.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBox_KeyPress);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(407, 277);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 82;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(9, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(481, 2);
            this.label1.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(5, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(481, 2);
            this.label2.TabIndex = 84;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(166, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1, 246);
            this.label3.TabIndex = 85;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(327, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1, 246);
            this.label4.TabIndex = 86;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 312);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

