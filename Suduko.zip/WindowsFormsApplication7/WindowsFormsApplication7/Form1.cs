﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] marr = { { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 },
                            { 1, 2, 3, 4, 5, 6, 7, 8, 9 }
                         };

            int txtcnt = 1;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    TextBox t = (TextBox)this.Controls["textBox" + txtcnt];//.Find("textBox" + txtcnt, false).FirstOrDefault();
                    t.BackColor = Color.White;
                    if (t.Text != "0")
                        marr[i, j] = Convert.ToInt32((t).Text);
                    else
                        marr[i, j] = 0;
                    txtcnt++;
                    string d = t.Name;
                }
                //  txtcnt++;
            }
        //    MessageBox.Show((marr[1, 1]).ToString());
            int x = 0, y = 8;
            int inputchkval = 9;
            bool xcheck, ycheck, sqcheck;
            int sqstart = 0, sqend = 0;
            int sqnumber = 0;
            xcheck = ycheck = sqcheck = false;
            for (int m = 0; m < 9; m++)
            {
                for (int n = 0; n < 9; n++)
                {
                    x = m; y = n;
                    inputchkval = marr[m, n];

                    //Horizontal
                    for (int i = 0; i < 9; i++)
                    {
                        if (y != i)
                        {
                            if (marr[x, i] != 0)
                                if (marr[x, i] == inputchkval)
                                {
                                    xcheck = true;
                                }
                        }

                    }
                    //vertical
                    for (int i = 0; i < 9; i++)
                    {
                        if (x != i) if (marr[i, y] != 0)
                                if (marr[i, y] == inputchkval)
                                {
                                    ycheck = true;
                                }
                    }
                    sqstart = (x / 3) * 3;
                    sqend = (y / 3) * 3;
                    
                    //squre
                    for (int i = sqstart; i < sqstart + 3; i++)
                    {
                        for (int j = sqend; j < sqend + 3; j++)
                        {
                            if (x != i && y != j) if (marr[i, j] != 0)
                                    if (marr[i, j] == inputchkval)
                                    {
                                        sqcheck = true;
                                    }
                        }
                    }

                    if (xcheck || ycheck || sqcheck)
                    {
                        MessageBox.Show("Repeat");
                        break;
                    }
                    else
                    {
                        // MessageBox.Show("OK");
                    }

                }
                if (xcheck || ycheck || sqcheck) {
                    if(sqcheck)
                    for (int i = sqstart; i < sqstart + 3; i++)
                    {
                        for (int j = sqend; j < sqend + 3; j++)
                        {
                           // if (x != i && y != j) if (marr[i, j] != 0)
                           //         if (marr[i, j] == inputchkval)
                                    {
                            //            sqcheck = true;
                                    }
                            ((TextBox)this.Controls["textBox" + ((i*9)+(j+1))]).BackColor=Color.Red;
                        }
                    }
                    if(ycheck)
                        for (int i = 0; i < 9; i++)
                        {
                            ((TextBox)this.Controls["textBox" + ((i * 9) + (y + 1))]).BackColor = Color.Red;
                            // if (x != i) if (marr[i, y] != 0)
                            // if (marr[i, y] == inputchkval)
                            {
                                  //      ycheck = true;
                                    }
                        }
                    if(xcheck)
                        for (int i = 0; i < 9; i++)
                        {
                            ((TextBox)this.Controls["textBox" + ((x * 9) + (i + 1))]).BackColor = Color.Red;

                            // if (y != i)
                            {
                                //  if (marr[x, i] != 0)
                                //  if (marr[x, i] == inputchkval)
                                {
                                   //     xcheck = true;
                                    }
                            }

                        }
                    break;
                }
            }

        }

        private void TxtBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
                e.Handled = true;
        }

        private void set()
        {

            for (int i = 1; i < 81; i = i * 9)
            {
                for (int j = i; j < i + 9; j++)
                {

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TextBox t = (TextBox)this.Controls.Find("textBox" + 1, false).FirstOrDefault();
            MessageBox.Show(t.Text);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            int txtcnt = 1;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    TextBox t = (TextBox)this.Controls["textBox" + txtcnt];//.Find("textBox" + txtcnt, false).FirstOrDefault();
                    t.BackColor = Color.White;
                    t.Text = "0";
                   // if (t.Text != "0")
                    //    marr[i, j] = Convert.ToInt32((t).Text);
                   // else
                     //   marr[i, j] = 0;
                    txtcnt++;
                    //string d = t.Name;
                }
                //  txtcnt++;
            }
        }
    }
}
