﻿using MouseKeyboardLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Web.Script.Serialization; 
namespace RepeatProc
{
    public partial class Form1 : Form
    {
        List<MacroEvent> events = new List<MacroEvent>();
        int lastTimeRecorded = 0;

        MouseHook mouseHook = new MouseHook();
        KeyboardHook keyboardHook = new KeyboardHook();

        public Form1()
        {
            InitializeComponent();
            mouseHook.MouseMove += new MouseEventHandler(mouseHook_MouseMove);
            mouseHook.MouseDown += new MouseEventHandler(mouseHook_MouseDown);
            mouseHook.MouseUp += new MouseEventHandler(mouseHook_MouseUp);

            keyboardHook.KeyDown += new KeyEventHandler(keyboardHook_KeyDown);
            keyboardHook.KeyUp += new KeyEventHandler(keyboardHook_KeyUp);
        }

        void mouseHook_MouseMove(object sender, MouseEventArgs e)
        {

            events.Add(
                new MacroEvent(
                    MacroEventType.MouseMove,
                    e,
                    Environment.TickCount - lastTimeRecorded
                ));

            lastTimeRecorded = Environment.TickCount;

        }

        void mouseHook_MouseDown(object sender, MouseEventArgs e)
        {

            events.Add(
                new MacroEvent(
                    MacroEventType.MouseDown,
                    e,
                    Environment.TickCount - lastTimeRecorded
                ));

            lastTimeRecorded = Environment.TickCount;

        }

        void mouseHook_MouseUp(object sender, MouseEventArgs e)
        {

            events.Add(
                new MacroEvent(
                    MacroEventType.MouseUp,
                    e,
                    Environment.TickCount - lastTimeRecorded
                ));

            lastTimeRecorded = Environment.TickCount;

        }

        void keyboardHook_KeyDown(object sender, KeyEventArgs e)
        {

            events.Add(
                new MacroEvent(
                    MacroEventType.KeyDown,
                    e,
                    Environment.TickCount - lastTimeRecorded
                ));

            lastTimeRecorded = Environment.TickCount;

        }

        void keyboardHook_KeyUp(object sender, KeyEventArgs e)
        {

            events.Add(
                new MacroEvent(
                    MacroEventType.KeyUp,
                    e,
                    Environment.TickCount - lastTimeRecorded
                ));

            lastTimeRecorded = Environment.TickCount;

        }

        private void recordStartButton_Click(object sender, EventArgs e)
        {
            ////create the serialiser to create the xml
            //XmlSerializer serialiser = new XmlSerializer(typeof(List<MacroEvent>));
            //// Create the TextWriter for the serialiser to use
            //TextWriter filestream = new StreamWriter(@"D:\output.xml");

            ////write to the file
            //serialiser.Serialize(filestream, events);

            //// Close the file
            //filestream.Close();

            events.Clear();
            lastTimeRecorded = Environment.TickCount;

            keyboardHook.Start();
            mouseHook.Start();

        }

        private void recordStopButton_Click(object sender, EventArgs e)
        {
            this.formatter = new BinaryFormatter();
            Save();
            keyboardHook.Stop();
            mouseHook.Stop();
        }
        private BinaryFormatter formatter;
        public void Save()
        {
          //  FileStream writerFileStream =
          //          new FileStream(@"D:\output.txt", FileMode.Create, FileAccess.Write);
            // Gain code access to the file that we are going
            // to write to
         
            //   filelocation
            try
            {
                string dfile = (DateTime.Now.ToString("yyyyMMddHHmmss")) + ".txt";
                string filelocation = System.Configuration.ConfigurationManager.AppSettings["filelocation"];
                //string filelocation = System.Configuration.ConfigurationManager.AppSettings["filelocation"];
                //string filelocation = System.Configuration.ConfigurationManager.AppSettings["filelocation"];
                string path = @filelocation + dfile;
                // Create a FileStream that will write data to file.
              
                // Save our dictionary of friends to file
                JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
                var strData = javaScriptSerializer.Serialize(this.events);
                File.WriteAllText(path, strData);
                string strDatar = File.ReadAllText(path);
                //  var persons2 = javaScriptSerializer.Deserialize<List<MacroEvent>>(strDatar);
                dynamic data1 = new List<MacroEvent>();
                // var persons2;
                var data = javaScriptSerializer.DeserializeObject(strDatar);
                var data3 = javaScriptSerializer.Deserialize<List<MyClass>>(strData);
                var ssd = javaScriptSerializer.ConvertToType<List<MacroEvent>>(data);
                //data.FirstOrDefault();
                //   var json = javaScriptSerializer.Serialize(persons2);


                Type General = data.GetType();
                //  Type General = typeof(data);
                // Close the writerFileStream when we are done.  
             //   this.formatter.Serialize(writerFileStream, this.events);
             //   writerFileStream.Close();
            }
            catch (Exception ex)
            {
              //  writerFileStream.Close();
                Console.WriteLine("Unable to save our friends' information");
            } // end try-catch
        } // end public bool Load()
      

        private void playBackMacroButton_Click(object sender, EventArgs e)
        {

            foreach (MacroEvent macroEvent in events)
            {

                Thread.Sleep(macroEvent.TimeSinceLastEvent);

                switch (macroEvent.MacroEventType)
                {
                    case MacroEventType.MouseMove:
                        {

                            MouseEventArgs mouseArgs = (MouseEventArgs)macroEvent.EventArgs;

                            MouseSimulator.X = mouseArgs.X;
                            MouseSimulator.Y = mouseArgs.Y;

                        }
                        break;
                    case MacroEventType.MouseDown:
                        {

                            MouseEventArgs mouseArgs = (MouseEventArgs)macroEvent.EventArgs;

                            MouseSimulator.MouseDown(mouseArgs.Button);

                        }
                        break;
                    case MacroEventType.MouseUp:
                        {

                            MouseEventArgs mouseArgs = (MouseEventArgs)macroEvent.EventArgs;

                            MouseSimulator.MouseUp(mouseArgs.Button);

                        }
                        break;
                    case MacroEventType.KeyDown:
                        {

                            KeyEventArgs keyArgs = (KeyEventArgs)macroEvent.EventArgs;

                            KeyboardSimulator.KeyDown(keyArgs.KeyCode);

                        }
                        break;
                    case MacroEventType.KeyUp:
                        {

                            KeyEventArgs keyArgs = (KeyEventArgs)macroEvent.EventArgs;

                            KeyboardSimulator.KeyUp(keyArgs.KeyCode);

                        }
                        break;
                    default:
                        break;
                }

            }

        }

        private void btnplayfile_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string file = openFileDialog1.FileName;

            playrecord(file);
        }
        public MacroEventType getfrom(int i)
        {
            switch (i)
            {
                case 0:
                    return MacroEventType.MouseMove;
                case 1:
                    return MacroEventType.MouseDown;
                case 2:
                    return MacroEventType.MouseUp;
                case 3:
                    return MacroEventType.MouseWheel;
                case 4:
                    return MacroEventType.KeyDown;
                case 5:
                    return MacroEventType.KeyUp;
                default:
                    return MacroEventType.MouseMove;

            }
        }
        public MouseButtons getMouseButtonsfrom(int i)
        {
            switch (i)
            {
                case 0:
                    return MouseButtons.None;
                case 1048576:
                    return MouseButtons.Left;
                case 2097152:
                    return MouseButtons.Right;
                case 4194304:
                    return MouseButtons.Middle;
                case 8388608:
                    return MouseButtons.XButton1;
                default:
                    return MouseButtons.XButton2; 
            }
        }

        //None = 0, 
        //Left = 1048576, 
        //Right = 2097152, 
        //Middle = 4194304, 
        //XButton1 = 8388608, 
        //XButton2 = 16777216
        public string  playrecord(string file)
        {
            string strDatar = File.ReadAllText(file);
            JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
            var strData = javaScriptSerializer.Deserialize<List<MacroEvent>>(strDatar);
            var data3 = javaScriptSerializer.Deserialize<List<MyClass>>(strDatar);
            List<MacroEvent> persons2 = new List<MacroEvent>();
            data3.ForEach(item =>
            {
            MacroEvent l = new MacroEvent();
            l.MacroEventType = (MacroEventType)(item.MacroEventType); // getfrom(item.MacroEventType);
            l.TimeSinceLastEvent = item.TimeSinceLastEvent;
                if (item.MacroEventType >= 0 && item.MacroEventType <= 3)
                {
                    var sm = new MouseEventArgs((MouseButtons)(item.EventArgs.Button), item.EventArgs.Clicks, item.EventArgs.X, item.EventArgs.Y, item.EventArgs.Delta);
                    //  sm.Location = new Point() { X = item.EventArgs.Location.X, Y = item.EventArgs.Location.Y);
                    l.EventArgs = sm;// new MouseEventArgs(MouseButtons.Left, 1, 1, 1, 1);
                }
                else
                {
                   
                    // item.EventArgs.
                    string k = Enum.GetName(typeof(Keys), item.EventArgs.Button);
                    Keys lk = (Keys)(item.EventArgs.KeyData);
                    l.EventArgs = new KeyEventArgs(lk);

                }
                persons2.Add(l);
            });

            foreach (MacroEvent macroEvent in persons2)
            {

                Thread.Sleep(macroEvent.TimeSinceLastEvent);

                switch (macroEvent.MacroEventType)
                {
                    case MacroEventType.MouseMove:
                        {

                            MouseEventArgs mouseArgs = (MouseEventArgs)macroEvent.EventArgs;

                            MouseSimulator.X = mouseArgs.X;
                            MouseSimulator.Y = mouseArgs.Y;

                        }
                        break;
                    case MacroEventType.MouseDown:
                        {

                            MouseEventArgs mouseArgs = (MouseEventArgs)macroEvent.EventArgs;

                            MouseSimulator.MouseDown(mouseArgs.Button);

                        }
                        break;
                    case MacroEventType.MouseUp:
                        {

                            MouseEventArgs mouseArgs = (MouseEventArgs)macroEvent.EventArgs;

                            MouseSimulator.MouseUp(mouseArgs.Button);

                        }
                        break;
                    case MacroEventType.KeyDown:
                        {

                            KeyEventArgs keyArgs = (KeyEventArgs)macroEvent.EventArgs;

                            KeyboardSimulator.KeyDown(keyArgs.KeyCode);

                        }
                        break;
                    case MacroEventType.KeyUp:
                        {

                            KeyEventArgs keyArgs = (KeyEventArgs)macroEvent.EventArgs;

                            KeyboardSimulator.KeyUp(keyArgs.KeyCode);

                        }
                        break;
                    default:
                        break;
                }

            }
            return "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string startfilerun = System.Configuration.ConfigurationManager.AppSettings["startfilerun"];
            try
            {
                string startfile = System.Configuration.ConfigurationManager.AppSettings["startfile"];
                if (startfilerun == "true")
                {
                    playrecord(startfile);
                    this.Close();
                }
            }
            catch (Exception)
            {

                 
            }
        }
    }
}
