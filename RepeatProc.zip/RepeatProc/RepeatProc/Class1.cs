﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RepeatProc
{
    /// <summary>
    /// All possible events that macro can record
    /// </summary>
    [Serializable]
    public enum MacroEventType
    {
        MouseMove,
        MouseDown,
        MouseUp,
        MouseWheel,
        KeyDown,
        KeyUp
    }

    /// <summary>
    /// Series of events that can be recorded any played back
    /// </summary>
    [Serializable]
    public class MacroEvent
    {

        public MacroEventType MacroEventType;
        MouseButtons Button = new MouseButtons();
        public EventArgs EventArgs;
       // public MouseEventArgs MouseEventArgse=new MouseEventArgs(MouseButtons.Left,1,1,1,1);
      //  public KeyEventArgs KeyEventArgs=new KeyEventArgs(Keys.I);
        public int TimeSinceLastEvent;
        public MacroEvent()
        {
        }
        //public MacroEvent(MacroEventType macroEventType, EventArgs eventArgs, int timeSinceLastEvent)
        //{

        //    MacroEventType = macroEventType;
        //    EventArgs = eventArgs;
        //    TimeSinceLastEvent = timeSinceLastEvent;

        //}
        public MacroEvent(MacroEventType macroEventType, MouseEventArgs eventArgs, int timeSinceLastEvent)
        {

            MacroEventType = macroEventType;
            EventArgs = eventArgs;
           // MouseEventArgse =new MouseEventArgs( eventArgs.Button,eventArgs.Clicks,eventArgs.X,eventArgs.Y,eventArgs.Delta);
            TimeSinceLastEvent = timeSinceLastEvent;
            //KeyEventArgs =  new KeyEventArgs(Keys.N);

        }
        public MacroEvent(MacroEventType macroEventType, KeyEventArgs eventArgs, int timeSinceLastEvent)
        {

            MacroEventType = macroEventType;
            EventArgs = eventArgs;
          //  KeyEventArgs =new KeyEventArgs(eventArgs.KeyData);
          //  MouseEventArgse = new MouseEventArgs(Button, 1, 1, 1, 1);
         TimeSinceLastEvent = timeSinceLastEvent;

        }
    }
    [Serializable]
    public class EventArgse : EventArgs
    {

    }
    [Serializable]
    public class MouseEventArgse : System.Windows.Forms.MouseEventArgs
    {
        internal MouseEventArgse(
            System.Windows.Forms.MouseButtons button,
            int clicks,
            int x,
            int y,
            int delta) : base(button, clicks, x, y, delta)
        {

        }
    }
    public class MyClass
    {
        public int MacroEventType { get; set; }
        public EventArge EventArgs { get; set; }
        public int TimeSinceLastEvent { get; set; }
    }
    public class EventArge
    {
        public int Button { get; set; }

        public int Clicks { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int Delta { get; set; }
        public Locatione Location { get; set; }

        public bool Alt { get; set; }
        public bool Control { get; set; }
        public bool Handled { get; set; }
        public int KeyCode { get; set; }
        public int KeyValue { get; set; }
        public int KeyData { get; set; }
        public int Modifiers { get; set; }
        public bool Shift { get; set; }
        public bool SuppressKeyPress { get; set; }
    }

    public class Locatione
    {
        public bool IsEmpty { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }

}
